import{C as r,r as e}from"./DhuUoSFX.js";r.register(...e);export{r as default};
