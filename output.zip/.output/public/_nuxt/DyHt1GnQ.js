import"./C4PqIVUo.js";const r=""+new URL("kongkang.DuITnXXo.jpg",import.meta.url).href;export{r as _};
