import{v as e,t as r}from"./C4PqIVUo.js";const s={__name:"Login",setup(i){return(o,n)=>(r(),e("button",{onClick:n[0]||(n[0]=(...t)=>o.login&&o.login(...t))},"Login with MSU"))}};export{s as default};
