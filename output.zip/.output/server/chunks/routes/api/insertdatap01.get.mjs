import { n as defineEventHandler } from '../../runtime.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'requrl';
import 'vue';
import 'node:url';

const prisma = new PrismaClient();
const insertdatap01_get = defineEventHandler(async (event) => {
  const {
    p01_id,
    p01_no,
    p01_name,
    p01_target,
    p01_score,
    p01_weight
  } = event.data;
  try {
    const res = await prisma.Datap01.create({
      data: {
        p01_id,
        p01_no,
        p01_name,
        p01_target,
        p01_score,
        p01_weight
      }
    });
    return res;
  } catch (error) {
    console.error("Error inserting data:", error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
});

export { insertdatap01_get as default };
//# sourceMappingURL=insertdatap01.get.mjs.map
