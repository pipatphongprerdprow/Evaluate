import { n as defineEventHandler } from '../../runtime.mjs';
import { PrismaClient } from '@prisma/client';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'requrl';
import 'vue';
import 'node:url';

const serve_get = defineEventHandler(async (event) => {
  const prisma = new PrismaClient();
  const res = await prisma.TrainCousre.findFirst({
    where: {
      course_id: 1
    }
  });
  return res;
});

export { serve_get as default };
//# sourceMappingURL=serve.get.mjs.map
