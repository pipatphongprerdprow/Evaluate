import { N as NuxtAuthHandler } from '../../../_/nuxtAuthHandler.mjs';
import '../../../runtime.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'requrl';
import 'vue';
import 'node:url';
import 'next-auth/core';

const _____ = NuxtAuthHandler({
  secret: "R31FG8G33cBnW7PrmEGj4SHeDV3cBs0rXTIDQDLdT3s=",
  // pages: {
  //   signIn: '/signin'
  // },
  providers: [
    // GoogleProvider.default({
    //   clientId: process.env.GOOGLE_CLIENT_ID,
    //   clientSecret: process.env.GOOGLE_CLIENT_SECRET
    // }),
    {
      id: "erpauth",
      name: "erpauth",
      type: "oauth",
      // OAuth 2.0 flow endpoints
      authorization: {
        url: "https://erp.msu.ac.th/authen/oauth/_authorize",
        params: {
          grant_type: "authorization_code",
          response_type: "code",
          redirect_uri: "https://survey.msu.ac.th/evaluate/api/auth/callback/erpauth",
          scope: ""
        }
      },
      token: "https://erp.msu.ac.th/authen/oauth/token",
      // Token endpoint
      userinfo: "https://erp.msu.ac.th/authen/api/authuser",
      // User info endpoint
      // Client ID and secret for the custom provider, from environment variables
      clientId: "9e04ac52-608f-4d13-8674-1374b228d6d0",
      clientSecret: "vertmZth5V0el1CN4LxZfzOyOch0DZ782RI0OQqI",
      // Function to extract the profile information from the userinfo response
      profile(profile) {
        var _a, _b;
        profile.user;
        return {
          id: profile.STAFFID,
          // Unique identifier
          // name: `${STAFFNAME} ${STAFFSURNAME}`, 
          name: profile,
          // User's name
          email: (_b = (_a = profile.STAFFEMAIL1) != null ? _a : profile.STAFFEMAIL2) != null ? _b : ""
          // User's email
          //image: STAFFID ,
          //...profile.user
        };
      }
    }
  ],
  session: {
    strategy: "jwt"
  },
  callbacks: {
    jwt: async ({ token, user, account, profile }) => {
      if (user == null ? void 0 : user.email) {
        token.providerInfo = {
          provider: account == null ? void 0 : account.provider,
          access_token: account == null ? void 0 : account.access_token,
          expire_at: account == null ? void 0 : account.expires_at,
          refresh_token: account == null ? void 0 : account.refresh_token
          //...user
        };
      }
      return Promise.resolve(token);
    },
    session: async ({ session, token, user }) => {
      session.providerInfo = token == null ? void 0 : token.providerInfo;
      return Promise.resolve({ ...session });
    }
  }
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
